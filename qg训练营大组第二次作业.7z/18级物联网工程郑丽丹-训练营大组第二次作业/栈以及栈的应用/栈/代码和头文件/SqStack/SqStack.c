#include <stdio.h>
#include <stdlib.h>
#include "SqStack.h" 

//˳��ջ(���������)
Status initStack(SqStack *s, int sizes)  //��ʼ��ջ
{
	s = (SqStack *)malloc(sizeof(SqStack));
	s->top = -1;
	s->size = sizes;
	if (s->top == -1)
	{
		return SUCCESS;
	}
	else 
	{
		return ERROR;
	}
}

Status isEmptyStack(SqStack *s)   //�ж�ջ�Ƿ�Ϊ��
{
	if (s->top == -1)
		return SUCCESS;
	return ERROR;
}

Status getTopStack(SqStack *s, ElemType *e)   //�õ�ջ��Ԫ��
{
	if (isEmptyStack(s) == 1)
	{
		printf("ջΪ�գ��޷��õ�ջ��Ԫ��\n");
	    return ERROR;
	}
	s->elem[s->top] = (*e);
	return SUCCESS; 
}

Status clearStack(SqStack *s)   //���ջ
{
	if (s->top == -1)
	{
		printf("ջ������\n");
		return ERROR;
	}
	s->top = -1;
	return SUCCESS;
}

Status destroyStack(SqStack *s)  //����ջ
{
	if (s->elem == NULL)
	{
		printf("�޷�����");
		return ERROR;
	}
	s->top = -1;
	free(s);
	return SUCCESS;
}

Status stackLength(SqStack *s, int *length)   //���ջ����
{
	if (s->top == -1)
		length = 0;
	(*length) = s->size;
	return SUCCESS; 
}
Status pushStack(SqStack *s, ElemType data)  //��ջ
{
	if (s->top == s->size-1)
	{
		printf("ջ��");
	    return ERROR;
	}
	else 
	{	
		s->top++; 
		s->size++;
		s->elem[s->size-1] = data;
		return SUCCESS;
	}
}

Status popStack(SqStack *s, ElemType *data)   //��ջ
{
	if (isEmptyStack(s) == 1)
	{
		printf("ջΪ��\n");
	    return ERROR;
	}
	else 
	{
		s->elem[s->top--] = (*data);
		s->size--;
		return SUCCESS;
	}
}

