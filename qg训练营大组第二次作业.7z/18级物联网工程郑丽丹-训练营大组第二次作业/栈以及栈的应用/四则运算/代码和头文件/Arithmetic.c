#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Arithmetic.h"

int isnumber(char ch)
{
    if(ch>='0'&&ch<='9')
        return 1;
    else
        return 0;
}
int isempty(stack *s)
{
    if(s->top==-1)
        return 1;
    else
        return 0;
}
void push(stack *s,char ch)
{
    s->data[++s->top]=ch;
}
void npush(nstack *s,char ch)
{
    s->data[++s->top]=ch-'0';
}
char pop(stack *s)
{
    return s->data[s->top--];
}
int npop(nstack *s)
{
    return s->data[s->top--];
}
int priority(char ch)
{
    if(ch=='(')
        return 0;
    if(ch=='+'||ch=='-')
        return 1;
    if(ch=='*'||ch=='/')
        return 2;
    if(ch=='^')
        return 3;
    return 0;
}
char top(stack *s)
{
    return s->data[s->top];
}
int ntop(nstack *s)
{
   	return s->data[s->top];
}
