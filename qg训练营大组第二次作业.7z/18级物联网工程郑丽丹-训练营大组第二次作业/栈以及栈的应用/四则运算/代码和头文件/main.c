#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Arithmetic.c"
#include "Arithmetic.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 
{
    int i,j,len,cnt;
    stack *st=(stack*)malloc(sizeof(stack));
    nstack *nst=(nstack*)malloc(sizeof(nstack));
    char str[85];
    char out[85];
    printf("��������׺����ʽ\n"); 
    scanf("%s",str);
    nst->top=-1;
    st->top=-1;
    cnt=0;
    len=strlen(str);
    for(i=0;i<len;i++)
	{
        if(isnumber(str[i]))
            out[cnt++]=str[i];
        else{
            if(str[i]=='('||isempty(st))
			{
                push(st,str[i]);
                continue;
            }
            if(str[i]==')')
			{
                while(top(st)!='(')
				{
                    out[cnt++]=top(st);
                    pop(st);
                }
                pop(st);
                continue;
            }
            while(!isempty(st)&&top(st)!='('&&priority(str[i])<=priority(top(st)))
			{
                out[cnt++]=top(st);
                pop(st);
            }
            push(st,str[i]);
        }
    }
    while(!isempty(st))
	{
        out[cnt++]=top(st);
        pop(st);
    }
    out[cnt]='\0';
    /*for(i=0;i<cnt;++i)
        printf("%c ",out[i]);
    printf("\n");*/
    for(i=0;i<cnt;i++)
	{
        if(isnumber(out[i]))
		{
            npush(nst,out[i]);
            continue;
        }
		else if(out[i]=='+')
		{
            nst->data[nst->top-1]+=ntop(nst);
            npop(nst);
        }
		else if(out[i]=='-')
		{
            nst->data[nst->top-1]-=ntop(nst);
            npop(nst);
        }
		else if(out[i]=='*')
		{
            nst->data[nst->top-1]*=ntop(nst);
            npop(nst);
        }
		else if(out[i]=='/')
		{
            nst->data[nst->top-1]/=ntop(nst);
            npop(nst);
        }
		else if(out[i]=='^')
		{
            nst->data[nst->top-1]=pow(nst->data[nst->top-1],ntop(nst));
            npop(nst);
        }
        for(j=0;j<=nst->top;++j)
        {
        	printf("%d ",nst->data[j]);
        }
        for(j=i+1;j<cnt;++j)
          	printf("%c ",out[j]);   	
        printf("\n");
    }
    return 0;
}
