#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#ifndef ARITHMETIC_H_INCLUDED
#define ARITHMETIC_H_INCLUDED

typedef struct{
    char data[85];
    int top;
}stack;
typedef struct{
    int data[85];
    int top;
}nstack;
int priority(char);  //��������� 
char pop(stack*);   //��ջ 
int npop(nstack*);
int ntop(nstack*);
char top(stack*);
void push(stack*,char);   //ѹջ 
void npush(nstack*,char);
int isnumber(char);  //�ж����� 
int isempty(stack*);  //�ж�ջ�Ƿ�� 

#endif
